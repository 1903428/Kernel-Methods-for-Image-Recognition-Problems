%% 两种核方法的识别结果文件

%% 导入的几个文件分别为：
%% ResultsetforWass 这个是采用Wasserstein核方法得到的是否正确的结果
%% identifiednumberforWass 这个是采用Wasserstein核方法识别出的数字
%% ResultsetforEuclid 这个是采用欧氏核方法得到的是否正确的结果
%% identifiednumberforEuclid 这个是采用欧氏核方法识别出的数字
ResultsetforWass = readmatrix('ResultsetforWass.csv');
identifiednumberforWass = readmatrix('identifiednumberforWass.csv');
ResultsetforEuclid = readmatrix('new_Resultset_for_Euclid.csv');
identifiednumberforEuclid = readmatrix('new_identified_number_for_Euclid.csv');

%% 查看两种方法的正确率
disp(mean(ResultsetforWass)); %% Wasserstein核方法的正确率为90.14%
disp(mean(ResultsetforEuclid)); %% 欧氏核方法的正确率为74.70%

%% 导入图像的数据
train_x_file='train-images.idx3-ubyte';%60000个训练集图片
test_x_file='t10k-images.idx3-ubyte'; %10000个测试集图片
train_y_file='train-labels.idx1-ubyte';%60000个训练集图片对应的数字 
test_y_file='t10k-labels.idx1-ubyte'; %10000个测试集图片对应的数字 

train_x=decodefile(train_x_file,'image');  
test_x=decodefile(test_x_file,'image');  
  
train_y=decodefile(train_y_file,'label');  
test_y=decodefile(test_y_file,'label');  
    
train_x_matrix=reshape(train_x,28,28,60000);%reshape后的图像是放倒的，行列颠倒   
train_x_matrix=permute(train_x_matrix,[2 1 3]);%对每张图像进行行列的转置处理，行列颠倒   
  
test_x_matrix=reshape(test_x,28,28,10000);%reshape后的图像是放倒的  
test_x_matrix=permute(test_x_matrix,[2 1 3]);%对每张图像进行行列的转置处理  

%% 两种方法的识别情况
%% flag_for_Wass即为Wasserstein核方法的识别结果
%% flag_for_Euclid即为欧氏核方法的识别结果
flag_for_Wass = zeros(10,10);
for ii = 1:10000
    for k=1:10
        for t=1:10
       if test_y(ii)== k-1 && identifiednumberforWass(ii)== t-1
      flag_for_Wass(t,k)=flag_for_Wass(t,k)+1;
       end
        end
    end
end

flag_for_Euclid = zeros(10,10);
for ii = 1:10000
    for k=1:10
        for t=1:10
       if test_y(ii)== k-1 && identifiednumberforEuclid(ii)== t-1
      flag_for_Euclid(t,k)=flag_for_Euclid(t,k)+1;
       end
        end
    end
end



%% 绘制两种方法的混淆矩阵（热力图）
%% h_Wass即为Wasserstein核方法的混淆矩阵
%% h_Euclid即为欧氏核方法的混淆矩阵
result_table3=table(flag_for_Wass);
writetable(result_table3,'flagforWass.csv');
result_table4=table(flag_for_Euclid);
writetable(result_table4,'flagforEuclid.csv');
label = {'0','1','2','3','4','5','6','7','8','9'};


h_Wass = heatmap(label,label,flag_for_Wass);
title('Wasserstein核方法的识别情况')
xlabel('正确数字')
ylabel('识别数字')


h_Euclid = heatmap(label,label,flag_for_Euclid);
title('欧氏核方法的识别情况')
xlabel('正确数字')
ylabel('识别数字')
