%% 测试文件
%% 测试采用基于Wasserstein度量的核方法时,训练集识别的正确情况

%% 添加文件
addpath("mnist_data\");
addpath("sinkhornTransport\");
%% 导入数据
train_x_file='train-images.idx3-ubyte';%60000个训练集图片
test_x_file='t10k-images.idx3-ubyte'; %10000个测试集图片
train_y_file='train-labels.idx1-ubyte';%60000个训练集图片对应的数字 
test_y_file='t10k-labels.idx1-ubyte'; %10000个测试集图片对应的数字 

train_x=decodefile(train_x_file,'image');  
test_x=decodefile(test_x_file,'image');  
  
train_y=decodefile(train_y_file,'label');  
test_y=decodefile(test_y_file,'label');  
    
train_x_matrix=reshape(train_x,28,28,60000);%reshape后的图像是放倒的，行列颠倒   
train_x_matrix=permute(train_x_matrix,[2 1 3]);%对每张图像进行行列的转置处理，行列颠倒   
  
test_x_matrix=reshape(test_x,28,28,10000);%reshape后的图像是放倒的  
test_x_matrix=permute(test_x_matrix,[2 1 3]);%对每张图像进行行列的转置处理  
 
%% 训练集分组
N = 60000;
index_zero = 1;   total_number_of_zero = 0;
index_one = 1;    total_number_of_one = 0;
index_two = 1;    total_number_of_two = 0;
index_three = 1;  total_number_of_three = 0;
index_four = 1;   total_number_of_four = 0;
index_five = 1;   total_number_of_five = 0;
index_six = 1;    total_number_of_six = 0;
index_seven = 1;  total_number_of_seven = 0;
index_eight = 1;  total_number_of_eight = 0;
index_nine = 1;   total_number_of_nine = 0;

AA_zero = zeros(28^2,60000);
AA_one = zeros(28^2,60000);
AA_two = zeros(28^2,60000);
AA_three = zeros(28^2,60000);
AA_four = zeros(28^2,60000);
AA_five = zeros(28^2,60000);
AA_six = zeros(28^2,60000);
AA_seven = zeros(28^2,60000);
AA_eight = zeros(28^2,60000);
AA_nine = zeros(28^2,60000);

for kk=1:N
     BB = train_x_matrix(:,:,kk);
    switch (train_y(kk))
        case (0)
            AA_zero(:,index_zero) = BB(:);
            index_zero = index_zero + 1;
            total_number_of_zero = total_number_of_zero + 1;
        case (1)
            AA_one(:,index_one) = BB(:);
            index_one = index_one + 1;
            total_number_of_one = total_number_of_one + 1;
        case (2)
            AA_two(:,index_two) = BB(:);
            index_two = index_two + 1;
            total_number_of_two = total_number_of_two + 1;
        case (3)
            AA_three(:,index_three) = BB(:);
            index_three = index_three + 1;
            total_number_of_three = total_number_of_three + 1;
        case (4)
            AA_four(:,index_four) = BB(:);
            index_four = index_four + 1;
            total_number_of_four = total_number_of_four + 1;
        case (5)
            AA_five(:,index_five) = BB(:);
            index_five = index_five + 1;
            total_number_of_five = total_number_of_five + 1;
        case (6)
            AA_six(:,index_six) = BB(:);
            index_six = index_six + 1;
            total_number_of_six = total_number_of_six + 1;
        case (7)
            AA_seven(:,index_seven) = BB(:);
            index_seven = index_seven + 1;
            total_number_of_seven = total_number_of_seven + 1;
        case (8)
            AA_eight(:,index_eight) = BB(:);
            index_eight = index_eight + 1;
            total_number_of_eight = total_number_of_eight + 1;
        case (9)
            AA_nine(:,index_nine) = BB(:);
            index_nine = index_nine + 1;
            total_number_of_nine = total_number_of_nine + 1;
    end
end

%% 设定参数
d = 28;
    [Matrix_A,Matrix_B] = ndgrid(1:d, 1:d);
    X = [Matrix_B(:),Matrix_A(:)];
    XX = X*X';
    M = sqrt(diag(XX)+diag(XX)'-2*XX);
    M = M/median(M(:));
lambda = 200;newsigma = 1000;
K=exp(-lambda*M);
U=K.*M;

 ii_zero = total_number_of_zero;
 ii_one = ii_zero + total_number_of_one; 
 ii_two = ii_one + total_number_of_two;
 ii_three = ii_two + total_number_of_three;
 ii_four = ii_three + total_number_of_four;
 ii_five = ii_four + total_number_of_five;
 ii_six = ii_five + total_number_of_six;
 ii_seven = ii_six + total_number_of_seven;
 ii_eight = ii_seven + total_number_of_eight;
 ii_nine = ii_eight + total_number_of_nine;

%% 组合矩阵
 combined_matrix = [AA_zero(:,1:total_number_of_zero),AA_one(:,1:total_number_of_one),AA_two(:,1:total_number_of_two),AA_three(:,1:total_number_of_three),AA_four(:,1:total_number_of_four),AA_five(:,1:total_number_of_five),AA_six(:,1:total_number_of_six),AA_seven(:,1:total_number_of_seven),AA_eight(:,1:total_number_of_eight),AA_nine(:,1:total_number_of_nine)];


%% 开始测试
Resultset_for_Wass = zeros(1,10000);
 p = parpool(4);
for m = 1:10000
Resultset_for_Wass(m) =  AnotherFigureRecognizer(m,combined_matrix,K,U,train_x_matrix,test_x_matrix,train_y,test_y,newsigma,ii_zero,ii_one,ii_two,ii_three,ii_four,ii_five,ii_six,ii_seven,ii_eight,ii_nine);
disp(num2str(m));
end
 delete(p);
 result_table=table(Resultset_for_Wass);
