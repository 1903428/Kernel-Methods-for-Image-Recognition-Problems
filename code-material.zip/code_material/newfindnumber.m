function [a,b] = FigureRecognizer(m) 

newsigma = 1000;

 CC = test_x_matrix(:,:,1);
 vectorized_text_x_matrix_first = CC(:);

DistanceVector=[0,0,0,0,0,0,0,0,0,0];
 
Distance_Between_zero = sinkhornTransport(vectorized_text_x_matrix_first,AA_zero(:,1:total_number_of_zero),K,U,200,[],[],[],[],1);
number_between_for_zero = mean(exp(-Distance_Between_zero.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_zero_is']);
disp(number_between_for_zero);
DistanceVector(1) = number_between_for_zero;

Distance_Between_one = sinkhornTransport(vectorized_text_x_matrix_first,AA_one(:,1:total_number_of_one),K,U,200,[],[],[],[],1);
number_between_for_one = mean(exp(-Distance_Between_one.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_one_is']);
disp(number_between_for_one);
DistanceVector(2) = number_between_for_one;

Distance_Between_two = sinkhornTransport(vectorized_text_x_matrix_first,AA_two(:,1:total_number_of_two),K,U,200,[],[],[],[],1);
number_between_for_two = mean(exp(-Distance_Between_two.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_two_is']);
disp(number_between_for_two);
DistanceVector(3) = number_between_for_two;

Distance_Between_three = sinkhornTransport(vectorized_text_x_matrix_first,AA_three(:,1:total_number_of_three),K,U,200,[],[],[],[],1);
number_between_for_three = mean(exp(-Distance_Between_three.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_three_is']);
disp(number_between_for_three);
DistanceVector(4) = number_between_for_three;

Distance_Between_four = sinkhornTransport(vectorized_text_x_matrix_first,AA_four(:,1:total_number_of_four),K,U,200,[],[],[],[],1);
number_between_for_four = mean(exp(-Distance_Between_four.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_four_is']);
disp(number_between_for_four);
DistanceVector(5) = number_between_for_four;

Distance_Between_five = sinkhornTransport(vectorized_text_x_matrix_first,AA_five(:,1:total_number_of_five),K,U,200,[],[],[],[],1);
number_between_for_five = mean(exp(-Distance_Between_five.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_five_is']);
disp(number_between_for_five);
DistanceVector(6) = number_between_for_five;

Distance_Between_six = sinkhornTransport(vectorized_text_x_matrix_first,AA_six(:,1:total_number_of_six),K,U,200,[],[],[],[],1);
number_between_for_six = mean(exp(-Distance_Between_six.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_six_is']);
disp(number_between_for_six);
DistanceVector(7) = number_between_for_six;

Distance_Between_seven = sinkhornTransport(vectorized_text_x_matrix_first,AA_seven(:,1:total_number_of_seven),K,U,200,[],[],[],[],1);
number_between_for_seven = mean(exp(-Distance_Between_seven.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_seven_is']);
disp(number_between_for_seven);
DistanceVector(8) = number_between_for_seven;

Distance_Between_eight = sinkhornTransport(vectorized_text_x_matrix_first,AA_eight(:,1:total_number_of_eight),K,U,200,[],[],[],[],1);
number_between_for_eight = mean(exp(-Distance_Between_eight.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_eight_is']);
disp(number_between_for_eight);
DistanceVector(9) = number_between_for_eight;

Distance_Between_nine = sinkhornTransport(vectorized_text_x_matrix_first,AA_nine(:,1:total_number_of_nine),K,U,200,[],[],[],[],1);
number_between_for_nine = mean(exp(-Distance_Between_nine.^2/(2*newsigma^2)),'omitmissing');
disp(['number_between_for_nine_is']);
disp(number_between_for_nine);
DistanceVector(10) = number_between_for_nine;

[value,index] = max(DistanceVector);
figure_number = index - 1;
disp(['the identified number is :']);
disp(figure_number);
disp(['the real number is :']);
disp(test_y(1));
if figure_number == test_y(1)
    disp(['Yes']);
else
    disp(['No']);
end

