%% 图像查看函数
%% 图像类别(class)分为训练图像(train)和测试图像(test)两种.
%% 若图像类别为测试图像时,参数m的范围在1~10000;
%% 若图像类别为训练图像时,参数m的范围在1~60000.
function [] = FigureDemo(m,class) %'class'是图像类别,分为训练图像(train)和测试图像(test)两种.
train_x_file='train-images.idx3-ubyte';%60000个训练集图片
test_x_file='t10k-images.idx3-ubyte'; %10000个测试集图片
train_y_file='train-labels.idx1-ubyte';%60000个训练集图片对应的数字 
test_y_file='t10k-labels.idx1-ubyte'; %10000个测试集图片对应的数字 
  
train_x=decodefile(train_x_file,'image');  
test_x=decodefile(test_x_file,'image');  
  
train_y=decodefile(train_y_file,'label');  
test_y=decodefile(test_y_file,'label');  
    
train_x_matrix=reshape(train_x,28,28,60000);%reshape后的图像是放倒的，行列颠倒   
train_x_matrix=permute(train_x_matrix,[2 1 3]);%对每张图像进行行列的转置处理，行列颠倒   
  
test_x_matrix=reshape(test_x,28,28,10000);%reshape后的图像是放倒的  
test_x_matrix=permute(test_x_matrix,[2 1 3]);%对每张图像进行行列的转置处理  
 
if strcmp(class,'test')
figure; 
axes('Position',[.1 .1 .8 .6]);
imshow(test_x_matrix(:,:,m),[]);  
title(['test : ',num2str(test_y(m))]); 
else 
    if strcmp(class,'train')
        figure; 
        axes('Position',[.1 .1 .8 .6]);
        imshow(train_x_matrix(:,:,m),[]);  
        title(['train : ',num2str(train_y(m))]);
    end
     
end