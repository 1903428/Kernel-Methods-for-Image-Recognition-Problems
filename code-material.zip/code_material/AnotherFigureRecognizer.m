function [figure_number,result] = AnotherFigureRecognizer(m,M,K,U,train_x_matrix,test_x_matrix,train_y,test_y,newsigma,ii_zero,ii_one,ii_two,ii_three,ii_four,ii_five,ii_six,ii_seven,ii_eight,ii_nine)
combined_matrix = M;
CC = test_x_matrix(:,:,m);
vectorized_text_x_matrix = CC(:);
 New_Distance_Between_zero = sinkhornTransport(vectorized_text_x_matrix,combined_matrix,K,U,200,[],[],[],[],1);
 New_number_between = exp(-New_Distance_Between_zero.^2/(2*newsigma^2));
 DistanceVector = [mean(New_number_between(:,1:ii_zero),'omitnan'),mean(New_number_between(:,(ii_zero+1):ii_one),'omitnan'),mean(New_number_between(:,(ii_one+1):ii_two),'omitnan'),mean(New_number_between(:,(ii_two+1):ii_three),'omitnan'),mean(New_number_between(:,(ii_three+1):ii_four),'omitnan'),mean(New_number_between(:,(ii_four+1):ii_five),'omitnan'),mean(New_number_between(:,(ii_five+1):ii_six),'omitnan'),mean(New_number_between(:,(ii_six+1):ii_seven),'omitnan'),mean(New_number_between(:,(ii_seven+1):ii_eight),'omitnan'),mean(New_number_between(:,(ii_eight+1):ii_nine),'omitnan')];
 [~,index] = max(DistanceVector);
 figure_number = index - 1;
     if figure_number == test_y(m)
      %% disp(['Yes for the ',num2str(m),'-th test']);
      result = 1;
     else
     %% disp(['No for the ',num2str(m),'-th test']);
      result = 0;
     end
end