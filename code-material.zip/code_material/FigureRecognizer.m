%% 图像识别函数
function [a,b] = FigureRecognizer(m,method,train_x_matrix,test_x_matrix,train_y,test_y)
%% 输出值a代表识别出的数字.
%% 输出值b代表是否识别成功.b=1代表识别成功,b=0代表识别失败.
%% 最后4个参数代表导入的训练集,测试集和他们对应的数字号码.

%% 训练集分组
N = 60000;
index_zero = 1;   total_number_of_zero = 0;
index_one = 1;    total_number_of_one = 0;
index_two = 1;    total_number_of_two = 0;
index_three = 1;  total_number_of_three = 0;
index_four = 1;   total_number_of_four = 0;
index_five = 1;   total_number_of_five = 0;
index_six = 1;    total_number_of_six = 0;
index_seven = 1;  total_number_of_seven = 0;
index_eight = 1;  total_number_of_eight = 0;
index_nine = 1;   total_number_of_nine = 0;

AA_zero = zeros(28^2,60000);
AA_one = zeros(28^2,60000);
AA_two = zeros(28^2,60000);
AA_three = zeros(28^2,60000);
AA_four = zeros(28^2,60000);
AA_five = zeros(28^2,60000);
AA_six = zeros(28^2,60000);
AA_seven = zeros(28^2,60000);
AA_eight = zeros(28^2,60000);
AA_nine = zeros(28^2,60000);

for kk=1:N
     BB = train_x_matrix(:,:,kk);
    switch (train_y(kk))
        case (0)
            AA_zero(:,index_zero) = BB(:);
            index_zero = index_zero + 1;
            total_number_of_zero = total_number_of_zero + 1;
        case (1)
            AA_one(:,index_one) = BB(:);
            index_one = index_one + 1;
            total_number_of_one = total_number_of_one + 1;
        case (2)
            AA_two(:,index_two) = BB(:);
            index_two = index_two + 1;
            total_number_of_two = total_number_of_two + 1;
        case (3)
            AA_three(:,index_three) = BB(:);
            index_three = index_three + 1;
            total_number_of_three = total_number_of_three + 1;
        case (4)
            AA_four(:,index_four) = BB(:);
            index_four = index_four + 1;
            total_number_of_four = total_number_of_four + 1;
        case (5)
            AA_five(:,index_five) = BB(:);
            index_five = index_five + 1;
            total_number_of_five = total_number_of_five + 1;
        case (6)
            AA_six(:,index_six) = BB(:);
            index_six = index_six + 1;
            total_number_of_six = total_number_of_six + 1;
        case (7)
            AA_seven(:,index_seven) = BB(:);
            index_seven = index_seven + 1;
            total_number_of_seven = total_number_of_seven + 1;
        case (8)
            AA_eight(:,index_eight) = BB(:);
            index_eight = index_eight + 1;
            total_number_of_eight = total_number_of_eight + 1;
        case (9)
            AA_nine(:,index_nine) = BB(:);
            index_nine = index_nine + 1;
            total_number_of_nine = total_number_of_nine + 1;
    end
end

%% 向量化需要判断的图像
CC = test_x_matrix(:,:,m);
vectorized_text_x_matrix = CC(:);


%% 若采用基于Wasserstein度量的核方法
if  strcmp(method,'Wass')
%% 构造参数矩阵
d = 28;
    [Matrix_A,Matrix_B] = ndgrid(1:d, 1:d);
    X = [Matrix_B(:),Matrix_A(:)];
    XX = X*X';
    M = sqrt(diag(XX)+diag(XX)'-2*XX);
    M = M/median(M(:));
lambda = 200;newsigma = 1000;
K=exp(-lambda*M);
U=K.*M;

%% 组合矩阵
 ii_zero = total_number_of_zero;
 ii_one = ii_zero + total_number_of_one;
 ii_two = ii_one + total_number_of_two;
 ii_three = ii_two + total_number_of_three;
 ii_four = ii_three + total_number_of_four;
 ii_five = ii_four + total_number_of_five;
 ii_six = ii_five + total_number_of_six;
 ii_seven = ii_six + total_number_of_seven;
 ii_eight = ii_seven + total_number_of_eight;
 ii_nine = ii_eight + total_number_of_nine;

 combined_matrix = [AA_zero(:,1:total_number_of_zero),AA_one(:,1:total_number_of_one),AA_two(:,1:total_number_of_two),AA_three(:,1:total_number_of_three),AA_four(:,1:total_number_of_four),AA_five(:,1:total_number_of_five),AA_six(:,1:total_number_of_six),AA_seven(:,1:total_number_of_seven),AA_eight(:,1:total_number_of_eight),AA_nine(:,1:total_number_of_nine)];
 
 %% 计算
 New_Distance_Between_zero = sinkhornTransport(vectorized_text_x_matrix,combined_matrix,K,U,200,[],[],[],[],1);
 New_number_between = exp(-New_Distance_Between_zero.^2/(2*newsigma^2));
 DistanceVector = [mean(New_number_between(:,1:ii_zero),'omitmissing'),mean(New_number_between(:,(ii_zero+1):ii_one),'omitmissing'),mean(New_number_between(:,(ii_one+1):ii_two),'omitmissing'),mean(New_number_between(:,(ii_two+1):ii_three),'omitmissing'),mean(New_number_between(:,(ii_three+1):ii_four),'omitmissing'),mean(New_number_between(:,(ii_four+1):ii_five),'omitmissing'),mean(New_number_between(:,(ii_five+1):ii_six),'omitmissing'),mean(New_number_between(:,(ii_six+1):ii_seven),'omitmissing'),mean(New_number_between(:,(ii_seven+1):ii_eight),'omitmissing'),mean(New_number_between(:,(ii_eight+1):ii_nine),'omitmissing')];
 [~,index] = max(DistanceVector);
 figure_number = index - 1;
 disp(['the identified number is :',num2str(figure_number)]);
 disp(['the real number is :',num2str(test_y(m))]);
     if figure_number == test_y(m)
      disp(['Yes for the ',num2str(m),'-th test']);
      b = 1;
     else
      disp(['No for the ',num2str(m),'-th test']);
      b = 0;
     end
      a = figure_number;

%% 若采用基于欧氏度量的核方法
else  
    if  strcmp(method,'Eulid')
     
%% 参数设定
another_sigma_square = 1000000;

%% 计算
Eulid_Kernel = [0,0,0,0,0,0,0,0,0,0];
Eulid_Kernel(1) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_zero)+1)-AA_zero(:,1:total_number_of_zero)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(2) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_one)+1)-AA_one(:,1:total_number_of_one)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(3) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_two)+1)-AA_two(:,1:total_number_of_two)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(4) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_three)+1)-AA_three(:,1:total_number_of_three)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(5) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_four)+1)-AA_four(:,1:total_number_of_four)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(6) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_five)+1)-AA_five(:,1:total_number_of_five)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(7) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_six)+1)-AA_six(:,1:total_number_of_six)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(8) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_seven)+1)-AA_seven(:,1:total_number_of_seven)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(9) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_eight)+1)-AA_eight(:,1:total_number_of_eight)).^2/(2*another_sigma_square)),'omitmissing');
Eulid_Kernel(10) = mean(exp(-(zeros(1,28^2)+1)*(vectorized_text_x_matrix*(zeros(1,total_number_of_nine)+1)-AA_nine(:,1:total_number_of_nine)).^2/(2*another_sigma_square)),'omitmissing');
[~,index_new] = max(Eulid_Kernel);
figure_number_new = index_new - 1;
a = figure_number_new;
disp(['the identified number is : ',num2str(figure_number_new)]);
disp(['the real number is : ',num2str(test_y(m))]);
         if figure_number_new == test_y(m)
      disp(['Yes for the test ',num2str(m)]);
      b = 1;
         else
      disp(['No for the test ',num2str(m)]);
      b = 0;
         end
    end
end
